module Shelley.Spec.Ledger.API
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.API' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.API as X
