module Shelley.Spec.Ledger.API.ByronTranslation
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.API.ByronTranslation' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.API.ByronTranslation as X
