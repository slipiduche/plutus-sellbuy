module Shelley.Spec.Ledger.API.Genesis
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.API.Genesis' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.API.Genesis as X
