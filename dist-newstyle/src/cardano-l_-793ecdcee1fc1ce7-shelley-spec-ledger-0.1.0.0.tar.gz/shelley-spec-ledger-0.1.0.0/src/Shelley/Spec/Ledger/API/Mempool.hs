module Shelley.Spec.Ledger.API.Mempool
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.API.Mempool' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.API.Mempool as X
