module Shelley.Spec.Ledger.API.Protocol
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.API.Protocol' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.API.Protocol as X
