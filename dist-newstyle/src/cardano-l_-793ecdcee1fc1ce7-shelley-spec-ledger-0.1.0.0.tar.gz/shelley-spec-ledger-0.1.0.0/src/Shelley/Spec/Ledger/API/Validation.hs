module Shelley.Spec.Ledger.API.Validation
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.API.Validation' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.API.Validation as X
