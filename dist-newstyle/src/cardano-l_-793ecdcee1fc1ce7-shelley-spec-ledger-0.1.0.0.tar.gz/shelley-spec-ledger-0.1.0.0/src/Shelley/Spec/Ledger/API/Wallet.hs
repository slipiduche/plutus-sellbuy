module Shelley.Spec.Ledger.API.Wallet
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.API.Wallet' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.API.Wallet as X
