module Shelley.Spec.Ledger.Address
  {-# DEPRECATED "Use 'import Cardano.Ledger.Address' instead." #-}
  (module X)
where

import Cardano.Ledger.Address as X
