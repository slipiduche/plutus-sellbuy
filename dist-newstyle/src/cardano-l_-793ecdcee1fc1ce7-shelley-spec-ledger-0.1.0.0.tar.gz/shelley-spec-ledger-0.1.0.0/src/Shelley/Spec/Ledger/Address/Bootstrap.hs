module Shelley.Spec.Ledger.Address.Bootstrap
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Address.Bootstrap' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Address.Bootstrap as X
