module Shelley.Spec.Ledger.BlockChain
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.BlockChain' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.BlockChain as X
