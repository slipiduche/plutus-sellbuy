module Shelley.Spec.Ledger.CompactAddr
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.CompactAddr' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.CompactAddr as X
