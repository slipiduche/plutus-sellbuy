module Shelley.Spec.Ledger.Delegation.Certificates
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Delegation.Certificates' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Delegation.Certificates as X
