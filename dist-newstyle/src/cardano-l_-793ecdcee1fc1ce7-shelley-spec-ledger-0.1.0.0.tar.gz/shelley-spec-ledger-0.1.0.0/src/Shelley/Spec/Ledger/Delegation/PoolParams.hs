module Shelley.Spec.Ledger.Delegation.PoolParams
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Delegation.PoolParams' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Delegation.PoolParams as X
