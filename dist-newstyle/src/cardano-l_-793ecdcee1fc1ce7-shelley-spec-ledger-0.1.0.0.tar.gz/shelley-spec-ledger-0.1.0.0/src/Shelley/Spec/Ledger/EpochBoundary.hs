module Shelley.Spec.Ledger.EpochBoundary
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.EpochBoundary' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.EpochBoundary as X
