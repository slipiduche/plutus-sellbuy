module Shelley.Spec.Ledger.Genesis
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Genesis' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Genesis as X
