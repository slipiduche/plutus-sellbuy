module Shelley.Spec.Ledger.HardForks
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.HardForks' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.HardForks as X
