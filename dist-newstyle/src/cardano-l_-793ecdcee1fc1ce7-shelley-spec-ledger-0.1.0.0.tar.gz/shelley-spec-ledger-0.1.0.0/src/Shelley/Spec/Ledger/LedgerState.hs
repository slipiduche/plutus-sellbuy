module Shelley.Spec.Ledger.LedgerState
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.LedgerState' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.LedgerState as X
