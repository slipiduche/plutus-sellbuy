module Shelley.Spec.Ledger.Metadata
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Metadata' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Metadata as X
