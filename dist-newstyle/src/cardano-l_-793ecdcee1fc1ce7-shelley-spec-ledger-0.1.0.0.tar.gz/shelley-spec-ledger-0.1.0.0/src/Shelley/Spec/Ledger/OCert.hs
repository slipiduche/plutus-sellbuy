module Shelley.Spec.Ledger.OCert
  {-# DEPRECATED "Use 'import Cardano.Protocol.TPraos.OCert' instead." #-}
  (module X)
where

import Cardano.Protocol.TPraos.OCert as X
