module Shelley.Spec.Ledger.Orphans
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Orphans' instead." #-}
  ()
where

import Cardano.Ledger.Shelley.Orphans ()
