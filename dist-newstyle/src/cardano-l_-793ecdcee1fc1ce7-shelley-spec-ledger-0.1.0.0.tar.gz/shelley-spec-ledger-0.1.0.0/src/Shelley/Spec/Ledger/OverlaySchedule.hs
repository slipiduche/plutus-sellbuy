module Shelley.Spec.Ledger.OverlaySchedule
  {-# DEPRECATED "Use 'import Cardano.Protocol.TPraos.Rules.Overlay' instead." #-}
  (module X)
where

import Cardano.Protocol.TPraos.Rules.Overlay as X
