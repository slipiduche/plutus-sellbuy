module Shelley.Spec.Ledger.PParams
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.PParams' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.PParams as X
