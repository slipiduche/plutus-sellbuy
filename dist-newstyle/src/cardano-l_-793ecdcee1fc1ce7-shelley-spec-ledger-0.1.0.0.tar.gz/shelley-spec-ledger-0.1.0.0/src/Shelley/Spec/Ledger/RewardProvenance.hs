module Shelley.Spec.Ledger.RewardProvenance
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.RewardProvenance' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.RewardProvenance as X
