module Shelley.Spec.Ledger.RewardUpdate
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.RewardUpdate' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.RewardUpdate as X
