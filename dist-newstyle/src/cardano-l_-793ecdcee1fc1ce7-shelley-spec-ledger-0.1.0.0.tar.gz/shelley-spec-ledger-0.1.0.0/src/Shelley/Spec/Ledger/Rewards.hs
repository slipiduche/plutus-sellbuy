module Shelley.Spec.Ledger.Rewards
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Rewards' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Rewards as X
