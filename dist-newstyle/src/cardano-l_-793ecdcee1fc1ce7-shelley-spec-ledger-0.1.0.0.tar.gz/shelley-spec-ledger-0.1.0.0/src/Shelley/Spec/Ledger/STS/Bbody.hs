module Shelley.Spec.Ledger.STS.Bbody
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Rules.Bbody' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Rules.Bbody as X
