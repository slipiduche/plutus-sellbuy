module Shelley.Spec.Ledger.STS.Deleg
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Rules.Deleg' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Rules.Deleg as X
