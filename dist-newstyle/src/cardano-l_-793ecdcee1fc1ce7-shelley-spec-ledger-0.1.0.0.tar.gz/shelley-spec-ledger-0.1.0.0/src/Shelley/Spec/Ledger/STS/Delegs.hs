module Shelley.Spec.Ledger.STS.Delegs
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Rules.Delegs' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Rules.Delegs as X
