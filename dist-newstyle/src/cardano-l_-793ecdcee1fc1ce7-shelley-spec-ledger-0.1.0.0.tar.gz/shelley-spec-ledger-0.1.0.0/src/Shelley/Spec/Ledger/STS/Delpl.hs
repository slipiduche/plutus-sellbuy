module Shelley.Spec.Ledger.STS.Delpl
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Rules.Delpl' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Rules.Delpl as X
