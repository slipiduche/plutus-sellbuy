module Shelley.Spec.Ledger.STS.Epoch
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Rules.Epoch' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Rules.Epoch as X
