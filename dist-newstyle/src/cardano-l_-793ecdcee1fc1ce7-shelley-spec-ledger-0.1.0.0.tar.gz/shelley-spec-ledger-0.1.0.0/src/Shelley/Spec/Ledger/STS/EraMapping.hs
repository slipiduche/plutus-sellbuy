module Shelley.Spec.Ledger.STS.EraMapping
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Rules.EraMapping' instead." #-}
  ()
where

import Cardano.Ledger.Shelley.Rules.EraMapping ()
