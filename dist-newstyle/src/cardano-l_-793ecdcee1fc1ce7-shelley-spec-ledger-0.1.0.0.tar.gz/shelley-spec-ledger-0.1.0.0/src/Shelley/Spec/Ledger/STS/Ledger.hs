module Shelley.Spec.Ledger.STS.Ledger
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Rules.Ledger' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Rules.Ledger as X
