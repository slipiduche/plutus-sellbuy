module Shelley.Spec.Ledger.STS.Ledgers
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Rules.Ledgers' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Rules.Ledgers as X
