module Shelley.Spec.Ledger.STS.Mir
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Rules.Mir' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Rules.Mir as X
