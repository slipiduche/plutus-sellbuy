module Shelley.Spec.Ledger.STS.NewEpoch
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Rules.NewEpoch' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Rules.NewEpoch as X
