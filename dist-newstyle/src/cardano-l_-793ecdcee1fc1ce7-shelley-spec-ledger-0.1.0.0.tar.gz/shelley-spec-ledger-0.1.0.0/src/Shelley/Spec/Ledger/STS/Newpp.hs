module Shelley.Spec.Ledger.STS.Newpp
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Rules.Newpp' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Rules.Newpp as X
