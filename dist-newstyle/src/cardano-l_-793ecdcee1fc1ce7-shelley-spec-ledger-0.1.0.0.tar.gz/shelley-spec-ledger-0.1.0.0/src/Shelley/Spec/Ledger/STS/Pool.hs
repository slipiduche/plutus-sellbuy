module Shelley.Spec.Ledger.STS.Pool
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Rules.Pool' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Rules.Pool as X
