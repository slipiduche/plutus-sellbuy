module Shelley.Spec.Ledger.STS.PoolReap
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Rules.PoolReap' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Rules.PoolReap as X
