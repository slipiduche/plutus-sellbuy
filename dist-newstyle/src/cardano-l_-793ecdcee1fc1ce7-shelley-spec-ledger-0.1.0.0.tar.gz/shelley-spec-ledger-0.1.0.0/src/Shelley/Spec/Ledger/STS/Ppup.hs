module Shelley.Spec.Ledger.STS.Ppup
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Rules.Ppup' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Rules.Ppup as X
