module Shelley.Spec.Ledger.STS.Prtcl
  {-# DEPRECATED "Use 'import Cardano.Protocol.TPraos.Rules.Prtcl' instead." #-}
  (module X)
where

import Cardano.Protocol.TPraos.Rules.Prtcl as X
