module Shelley.Spec.Ledger.STS.Rupd
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Rules.Rupd' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Rules.Rupd as X
