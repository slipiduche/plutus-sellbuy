module Shelley.Spec.Ledger.STS.Snap
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Rules.Snap' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Rules.Snap as X
