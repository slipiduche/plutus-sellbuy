module Shelley.Spec.Ledger.STS.Tick
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Rules.Tick' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Rules.Tick as X
