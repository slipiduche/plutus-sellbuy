module Shelley.Spec.Ledger.STS.Tickn
  {-# DEPRECATED "Use 'import Cardano.Protocol.TPraos.Rules.Tickn' instead." #-}
  (module X)
where

import Cardano.Protocol.TPraos.Rules.Tickn as X
