module Shelley.Spec.Ledger.STS.Updn
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Rules.Updn' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Rules.Updn as X
