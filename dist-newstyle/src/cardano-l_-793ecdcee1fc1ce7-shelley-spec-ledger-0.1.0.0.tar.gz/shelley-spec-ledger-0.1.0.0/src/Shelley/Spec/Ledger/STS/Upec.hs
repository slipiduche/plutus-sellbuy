module Shelley.Spec.Ledger.STS.Upec
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Rules.Upec' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Rules.Upec as X
