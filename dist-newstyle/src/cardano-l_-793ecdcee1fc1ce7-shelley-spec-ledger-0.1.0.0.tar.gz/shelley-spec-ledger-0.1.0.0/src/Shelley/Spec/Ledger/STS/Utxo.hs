module Shelley.Spec.Ledger.STS.Utxo
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Rules.Utxo' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Rules.Utxo as X
