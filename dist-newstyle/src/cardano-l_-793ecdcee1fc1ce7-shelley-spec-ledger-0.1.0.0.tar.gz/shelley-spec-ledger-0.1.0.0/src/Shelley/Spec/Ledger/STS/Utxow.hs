module Shelley.Spec.Ledger.STS.Utxow
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Rules.Utxow' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Rules.Utxow as X
