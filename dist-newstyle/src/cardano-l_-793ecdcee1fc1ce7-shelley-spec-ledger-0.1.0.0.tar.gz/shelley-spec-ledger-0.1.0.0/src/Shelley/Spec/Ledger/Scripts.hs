module Shelley.Spec.Ledger.Scripts
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Scripts' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Scripts as X
