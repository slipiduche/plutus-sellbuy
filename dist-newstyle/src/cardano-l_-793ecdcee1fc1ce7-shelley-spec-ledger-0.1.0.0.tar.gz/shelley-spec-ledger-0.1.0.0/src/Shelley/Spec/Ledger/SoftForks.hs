module Shelley.Spec.Ledger.SoftForks
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.SoftForks' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.SoftForks as X
