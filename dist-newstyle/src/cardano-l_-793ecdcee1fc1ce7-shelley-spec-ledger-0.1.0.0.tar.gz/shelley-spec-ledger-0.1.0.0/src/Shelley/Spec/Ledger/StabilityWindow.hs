module Shelley.Spec.Ledger.StabilityWindow
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.StabilityWindow' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.StabilityWindow as X
