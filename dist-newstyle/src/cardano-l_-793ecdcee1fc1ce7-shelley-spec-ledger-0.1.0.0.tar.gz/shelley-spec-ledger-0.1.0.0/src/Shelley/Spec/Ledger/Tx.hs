module Shelley.Spec.Ledger.Tx
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.Tx' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.Tx as X
