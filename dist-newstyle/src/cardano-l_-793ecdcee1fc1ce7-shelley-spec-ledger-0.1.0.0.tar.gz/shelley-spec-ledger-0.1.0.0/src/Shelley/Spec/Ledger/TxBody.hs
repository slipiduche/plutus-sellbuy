module Shelley.Spec.Ledger.TxBody
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.TxBody' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.TxBody as X
