module Shelley.Spec.Ledger.UTxO
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.UTxO' instead." #-}
  (module X)
where

import Cardano.Ledger.Shelley.UTxO as X
