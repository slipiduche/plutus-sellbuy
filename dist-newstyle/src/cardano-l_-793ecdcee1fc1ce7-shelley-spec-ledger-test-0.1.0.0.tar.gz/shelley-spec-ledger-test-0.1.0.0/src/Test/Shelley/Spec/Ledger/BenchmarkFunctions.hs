module Test.Shelley.Spec.Ledger.BenchmarkFunctions
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.BenchmarkFunctions' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.BenchmarkFunctions as X
