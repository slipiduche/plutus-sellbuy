module Test.Shelley.Spec.Ledger.ConcreteCryptoTypes
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.ConcreteCryptoTypes' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.ConcreteCryptoTypes as X
