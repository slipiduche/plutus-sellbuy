module Test.Shelley.Spec.Ledger.Examples.Cast
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Examples.Cast' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Examples.Cast as X
