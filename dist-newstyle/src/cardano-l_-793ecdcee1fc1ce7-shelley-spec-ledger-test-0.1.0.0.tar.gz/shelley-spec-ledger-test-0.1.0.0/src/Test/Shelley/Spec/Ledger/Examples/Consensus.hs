module Test.Shelley.Spec.Ledger.Examples.Consensus
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Examples.Consensus' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Examples.Consensus as X
