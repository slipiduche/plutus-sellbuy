module Test.Shelley.Spec.Ledger.Generator.Block
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Generator.Block' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Generator.Block as X
