module Test.Shelley.Spec.Ledger.Generator.Constants
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Generator.Constants' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Generator.Constants as X
