module Test.Shelley.Spec.Ledger.Generator.Core
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Generator.Core' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Generator.Core as X
