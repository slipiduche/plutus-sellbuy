module Test.Shelley.Spec.Ledger.Generator.Delegation
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Generator.Delegation' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Generator.Delegation as X
