module Test.Shelley.Spec.Ledger.Generator.EraGen
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Generator.EraGen' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Generator.EraGen as X
