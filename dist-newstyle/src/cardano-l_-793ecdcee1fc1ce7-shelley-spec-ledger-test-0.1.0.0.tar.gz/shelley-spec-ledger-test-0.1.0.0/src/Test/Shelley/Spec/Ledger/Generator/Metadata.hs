module Test.Shelley.Spec.Ledger.Generator.Metadata
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Generator.Metadata' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Generator.Metadata as X
