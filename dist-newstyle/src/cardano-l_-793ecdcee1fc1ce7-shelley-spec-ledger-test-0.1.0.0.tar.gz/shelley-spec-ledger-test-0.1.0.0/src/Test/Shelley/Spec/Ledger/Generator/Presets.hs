module Test.Shelley.Spec.Ledger.Generator.Presets
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Generator.Presets' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Generator.Presets as X
