module Test.Shelley.Spec.Ledger.Generator.ScriptClass
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Generator.ScriptClass' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Generator.ScriptClass as X
