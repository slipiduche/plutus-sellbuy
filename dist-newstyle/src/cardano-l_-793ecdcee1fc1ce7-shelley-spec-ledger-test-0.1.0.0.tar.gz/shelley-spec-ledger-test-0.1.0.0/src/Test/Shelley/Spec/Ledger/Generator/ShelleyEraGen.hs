module Test.Shelley.Spec.Ledger.Generator.ShelleyEraGen
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Generator.ShelleyEraGen' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Generator.ShelleyEraGen as X
