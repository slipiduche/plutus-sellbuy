module Test.Shelley.Spec.Ledger.Generator.Trace.Chain
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Generator.Trace.Chain' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Generator.Trace.Chain as X
