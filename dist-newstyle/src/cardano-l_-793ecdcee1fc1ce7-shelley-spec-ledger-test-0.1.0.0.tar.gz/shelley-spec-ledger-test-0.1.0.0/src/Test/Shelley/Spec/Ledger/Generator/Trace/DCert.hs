module Test.Shelley.Spec.Ledger.Generator.Trace.DCert
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Generator.Trace.DCert' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Generator.Trace.DCert as X
