module Test.Shelley.Spec.Ledger.Generator.Trace.Ledger
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Generator.Trace.Ledger' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Generator.Trace.Ledger as X
