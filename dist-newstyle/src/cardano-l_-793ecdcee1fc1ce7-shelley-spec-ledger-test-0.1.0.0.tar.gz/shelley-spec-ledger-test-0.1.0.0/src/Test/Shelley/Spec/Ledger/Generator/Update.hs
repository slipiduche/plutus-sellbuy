module Test.Shelley.Spec.Ledger.Generator.Update
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Generator.Update' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Generator.Update as X
