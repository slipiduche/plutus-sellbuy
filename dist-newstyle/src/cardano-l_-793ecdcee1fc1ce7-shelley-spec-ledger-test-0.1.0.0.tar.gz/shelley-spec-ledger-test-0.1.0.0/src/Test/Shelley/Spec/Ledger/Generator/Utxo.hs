module Test.Shelley.Spec.Ledger.Generator.Utxo
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Generator.Utxo' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Generator.Utxo as X
