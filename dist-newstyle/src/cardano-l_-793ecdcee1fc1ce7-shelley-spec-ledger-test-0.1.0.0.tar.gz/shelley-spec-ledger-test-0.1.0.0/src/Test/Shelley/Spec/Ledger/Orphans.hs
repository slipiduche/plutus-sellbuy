module Test.Shelley.Spec.Ledger.Orphans
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Orphans' instead." #-}
  ()
where

import Test.Cardano.Ledger.Shelley.Orphans ()
