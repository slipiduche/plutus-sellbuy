module Test.Shelley.Spec.Ledger.PropertyTests
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.PropertyTests' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.PropertyTests as X
