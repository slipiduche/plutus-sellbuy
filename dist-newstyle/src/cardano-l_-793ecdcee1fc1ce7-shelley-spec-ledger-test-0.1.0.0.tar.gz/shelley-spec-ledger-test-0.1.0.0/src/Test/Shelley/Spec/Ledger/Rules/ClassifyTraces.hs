module Test.Shelley.Spec.Ledger.Rules.ClassifyTraces
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Rules.ClassifyTraces' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Rules.ClassifyTraces as X
