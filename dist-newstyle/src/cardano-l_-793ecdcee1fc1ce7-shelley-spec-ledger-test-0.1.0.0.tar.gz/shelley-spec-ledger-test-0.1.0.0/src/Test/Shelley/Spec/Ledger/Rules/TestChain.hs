module Test.Shelley.Spec.Ledger.Rules.TestChain
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Rules.TestChain' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Rules.TestChain as X
