module Test.Shelley.Spec.Ledger.Serialisation.CDDLUtils
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Serialisation.CDDLUtils' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Serialisation.CDDLUtils as X
