module Test.Shelley.Spec.Ledger.Serialisation.EraIndepGenerators
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Serialisation.EraIndepGenerators' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Serialisation.EraIndepGenerators as X
