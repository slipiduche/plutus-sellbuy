module Test.Shelley.Spec.Ledger.Serialisation.Generators
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Serialisation.Generators' instead." #-}
  ()
where

import Test.Cardano.Ledger.Shelley.Serialisation.Generators ()
