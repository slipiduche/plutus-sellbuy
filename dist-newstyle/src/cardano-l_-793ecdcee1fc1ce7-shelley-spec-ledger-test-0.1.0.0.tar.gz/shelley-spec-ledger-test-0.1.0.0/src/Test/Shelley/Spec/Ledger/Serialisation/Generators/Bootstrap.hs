module Test.Shelley.Spec.Ledger.Serialisation.Generators.Bootstrap
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Serialisation.Generators.Bootstrap' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Serialisation.Generators.Bootstrap as X
