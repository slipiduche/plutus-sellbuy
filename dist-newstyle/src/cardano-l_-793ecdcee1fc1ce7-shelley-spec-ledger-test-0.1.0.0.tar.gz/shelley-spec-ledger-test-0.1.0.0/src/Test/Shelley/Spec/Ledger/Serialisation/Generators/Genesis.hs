module Test.Shelley.Spec.Ledger.Serialisation.Generators.Genesis
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Serialisation.Generators.Genesis' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Serialisation.Generators.Genesis as X
