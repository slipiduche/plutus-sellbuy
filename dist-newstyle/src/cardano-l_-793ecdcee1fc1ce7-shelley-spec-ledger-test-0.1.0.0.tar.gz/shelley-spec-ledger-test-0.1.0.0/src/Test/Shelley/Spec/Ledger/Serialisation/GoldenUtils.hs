module Test.Shelley.Spec.Ledger.Serialisation.GoldenUtils
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Serialisation.GoldenUtils' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Serialisation.GoldenUtils as X
