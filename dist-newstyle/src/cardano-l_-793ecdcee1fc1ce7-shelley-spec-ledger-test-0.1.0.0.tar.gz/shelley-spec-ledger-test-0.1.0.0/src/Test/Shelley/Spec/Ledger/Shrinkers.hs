module Test.Shelley.Spec.Ledger.Shrinkers
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Shrinkers' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Shrinkers as X
