module Test.Shelley.Spec.Ledger.Utils
  {-# DEPRECATED "Use 'import Test.Cardano.Ledger.Shelley.Utils' instead." #-}
  (module X)
where

import Test.Cardano.Ledger.Shelley.Utils as X
