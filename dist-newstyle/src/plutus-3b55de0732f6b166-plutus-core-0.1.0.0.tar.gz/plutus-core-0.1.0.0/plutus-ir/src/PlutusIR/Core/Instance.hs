module PlutusIR.Core.Instance () where

import PlutusIR.Core.Instance.Flat ()
import PlutusIR.Core.Instance.Pretty ()
import PlutusIR.Core.Instance.Scoping ()
